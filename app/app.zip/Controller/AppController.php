<?php

App::uses('Controller', 'Controller');

class AppController extends Controller {

    public $uses = array('Category', 'Post','Tag');
    public $helpers = array('Text', 'Form', 'Html', 'Session', 'Cache','Facebook.Facebook','Utility.OpenGraph', 'Utility.Breadcrumb');
    public $components = array(
        'RequestHandler',
        'Session',
        'Cookie',
        'Auth' => array('authorize' => array('Controller' => 'users'),
            //'logoutRedirect' => array('controller' => 'users', 'action' => 'login', 'admin' => true))
            'logoutRedirect' => array('controller' => 'pages', 'action' => 'home', 'admin' => false))
    );

    public function isAuthorized($user) {
        // Chacun des utilisateur enregistré peut accéder aux fonctions publiques
        if (empty($this->request->params['admin'])) {
            return true;
        }

        // Seulement les administrateurs peuvent accéder aux fonctions d'administration
        if (isset($this->request->params['admin'])) {
            return (bool) ($user['Role']['name'] === 'admin');
        }

        // Par défaut n'autorise pas
        return false;
    }

    public function beforeFilter() {
        parent::beforeFilter();
        $this->set('loggedIn', $this->Auth->loggedIn());
        $this->set('currentUser', $this->Auth->user());
        $optionsWidgets = array(
            'conditions' => array('Post.type' => 'post', 'Post.online' => 1),
            'order' => array('Post.created DESC'),
            'limit' => 4
        );
        $this->set('widgets',$this->Post->find('all',$optionsWidgets));
        $this->set('tags',$this->Tag->find('all',array('limit'=>'10','order'=>'Tag.id DESC')));
        $this->set('categories',$this->Category->find('all',array('limit'=>7,'order'=>'Category.id DESC')));
    }

    function beforeRender() {
        parent::beforeRender();

        if (isset($this->params['prefix']) && $this->params['prefix'] == 'admin' && !$this->params['isAjax']) {
            $this->layout = 'admin_default';
        }

        // Pour le layout public
        else {
            $this->set('categoriesM', $this->Category->categoriesM());
            $this->set('categoriesD', $this->Category->categoriesD());
            $this->set('pagesD', $this->Post->pagesDrop());
            $this->set('pop_post', $this->Post->popular_post());
            $this->layout = 'default';
        }
    }

}
