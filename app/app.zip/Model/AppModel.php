<?php

App::uses('Model', 'Model');

class AppModel extends Model {

    public $actsAs = array('Containable');

}
